from flask import render_template, flash, redirect, session, url_for, request, g, send_file, Blueprint
from flask.ext.login import login_user, logout_user, current_user, login_required
#from mysite import db, lm, oid
from forms import LoginForm
from mysite import models
import data_functions as df
import team_info_functions as tf
from sqlalchemy import and_, or_
from datetime import datetime

from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
import random
import StringIO
from flask import make_response


mod = Blueprint('main', __name__,url_prefix='/')

@mod.route('/')
@mod.route('/index')
def index():

    return render_template('index.html')

@mod.route('/plot')
def plot():
    fig = Figure()
    axis = fig.add_subplot(1, 1, 1)

    xs = range(100)
    ys = [random.randint(1, 50) for x in xs]

    axis.plot(xs, ys)
    canvas = FigureCanvas(fig)
    img = StringIO.StringIO()
    fig.savefig(img)
    img.seek(0)
    return send_file(img, mimetype='image/png')
@mod.route('/images')
def images():

    return render_template('index.html')

@mod.app_errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@mod.app_errorhandler(500)
def internal_error(error):
    #db.session.rollback()
    return render_template('500.html'), 500