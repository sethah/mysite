import os
from flask import Flask, Blueprint
from flask.ext.sqlalchemy import SQLAlchemy
from flask.ext.login import LoginManager
from flask.ext.openid import OpenID
from config import basedir



app = Flask(__name__)
app.config.from_object('config')
db = SQLAlchemy(app)
'''lm = LoginManager()
lm.init_app(app)
lm.login_view = 'login'
oid = OpenID(app, os.path.join(basedir, 'tmp'))'''

from mysite.data_functions import myround
import table_functions as tbl

from mysite.game.views import mod as gameModule
from mysite.teams.views import mod as teamsModule
from mysite.views import mod as mainModule

app.register_blueprint(mainModule)
app.register_blueprint(gameModule)
app.register_blueprint(teamsModule)
'''def register_blueprints(app):
    # Prevents circular imports
    #from mysite.game.views import mod as gameModule
    from mysite.views import mod as mainModule

    app.register_blueprint(mainModule)
    #app.register_blueprint(gameModule)

register_blueprints(app)'''