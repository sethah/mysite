from mysite import models
from datetime import datetime
from flask import flash

def myround(x, base=5):
    return int(base * round(float(x)/base))

def get_team_param(the_team,convert_from):
    '''
    @Function: get_team_param(team,convert_from)
    @Author: S. Hendrickson 1/11/14
    @Return: This function indexes a lookup table and finds the
    convert_from value and returns the convert_to value in the
    found row.
    '''

    q = models.team.query.filter(getattr(models.team,convert_from)==the_team).first()
    try:
        return q
    except AttributeError:
        return None
def win_loss_invert(outcome):
    if outcome == 'W':
        return 'L'
    elif outcome == 'L':
        return 'W'
    else:
        return None
def get_ncaa_schedule_data(teamID):
    '''
    @Function: get_ncaa_schedule_data(teamID)
    @Author: S. Hendrickson 3/5/14
    @Return: This function returns various lists holding information
    about the team's games.
    '''
    link = 'http://stats.ncaa.org/team/index/11540?org_id='+teamID
    po = models.Page_Opener()
    soup = po.open_and_soup(link)

    #get the table that contains 'Schedule' in its first row
    tables = soup.findAll('table')
    tables = [table for table in tables if 'Schedule' in table.findAll('tr')[0].get_text()]
    table = tables[0]

    #get all the game rows that have been played
    rows = table.findAll('tr')

    #get all rows with more than zero cells and with a 'W' or an 'L' in the last cell
    rows = [row for row in rows if len(row.findAll('td', {'class' : 'smtext'})) > 0 and ('W' in row.findAll('td')[-1].get_text() or 'L' in row.findAll('td')[-1].get_text())]

    dates = []
    outcomes = []
    opponents = []
    locations = []
    links = []
    games = []
    real_locations = []
    box_links = []
    fmt =  '%m/%d/%Y'
    for row in rows:
        #get the date
        tds = row.findAll('td')
        date = datetime.datetime.strptime(tds[0].get_text(),fmt)
        dates.append(date)

        #get the location
        string = str(tds[1].get_text())
        string = string.strip()
        if string[0:1] == '@':
            location = 'Away'
        elif '@' in string:
            #if @ is not the first character, it is a neutral game
            location = 'Neutral'
        else:
            location = 'Home'

        #get the opponent
        opponent = tds[1].find('a')['href']
        opponent = opponent[opponent.find('=')+1:len(opponent)]

        #get the data from the souped table
        string = tds[-1].get_text().strip()
        outcome = str(string[0:1].upper())
        link = tds[-1].find('a')['href']
        index = link[link.index('index/')+len('index/'):link.index('?')]
        link = 'http://stats.ncaa.org/game/play_by_play/'+index
        box_link = 'http://stats.ncaa.org/game/box_score/'+index

        #append data to the lists
        box_links.append(box_link)
        links.append(link)
        outcomes.append(outcome)
        locations.append(location)
        opponents.append(opponent)
        games.append([teamID,opponent,date])

    #real locations no longer returned
    return links, box_links, outcomes, locations, real_locations, opponents, dates, games
