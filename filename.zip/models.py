<!-- extend base layout -->
<html>
  <html lang="en">
  <head>
  <meta charset="utf-8" />
    <link href="/static/css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="/static/css/bootstrap-responsive.css" rel="stylesheet">
    <link href="/static/css/tablecloth.css" rel="stylesheet" type="text/css" media="screen">
    <link href="/static/css/prettify.css" rel="stylesheet">
    <link href="/static/css/jq.css" rel="stylesheet">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>B1GStats</title>
    
  </head>

<body>

    <script src="/static/js/jquery-1.7.2.min.js"></script>
    <script src="/static/js/bootstrap.js"></script>
    <script src="/static/js/jquery.metadata.js"></script>
    <script src="/static/js/jquery.tablesorter.min.js"></script>
    <script src="/static/js/jquery.tablecloth.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <div class="container">
        <header class="navbar navbar-default navbar-static-top" role="banner">
            <div class="navbar">
                <div class="navbar-inner">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="/">B1G Stats</a>

                    <ul id="navigation" class="nav nav-tabs">
                        
                            <li class="active"><a href="/index">Home</a>
                            </li>
                        
                            <li><a href="/teams/">Teams</a>
                            </li>
                        
                    </ul>
                </div>
            </div>
        </header>

        
        <div id='content' class='row-fluid'>
            <div class="span3 sidebar" id="leftCol">
                <div class="well">
                  	<ul class="nav nav-stacked" id="sidebar">
                      <li><a href="#sec1">Section 1</a></li>
                      <li><a href="#sec2">Section 2</a></li>
                      <li><a href="#sec3">Section 3</a></li>
                      <li><a href="#sec4">Section 4</a></li>
                  	</ul>
  				</div>
      		</div>
            <div class='span9 main'>
                
<h1>File Not Found</h1>
<p><a href="/index">Back</a></p>

            </div>
        </div>
    </div>
  </body>
</html>